package com.example.listado_de_alumnos

data class Alumno (
    val nombre: String,
    val cuenta: String,
    val correo: String,
    val imagen: String
)