package com.example.listado_de_alumnos

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Vinculamos el RecyclerView con main activity
        val recyclerViewOk = findViewById<RecyclerView>(R.id.recyclerVWalumnos)

        recyclerViewOk.layoutManager = LinearLayoutManager(this)

        val Alumnos_List = listOf<Alumno>(
            Alumno(
                nombre = "Sofía Amezcua",
                cuenta = "20187649",
                imagen = "https://i.pinimg.com/736x/71/26/eb/7126ebc5abf282c1cab3f50c1d796378.jpg",
                correo = "samezcua@ucol.mx"
            ),
            Alumno(
                nombre = "Luis Gónzalez",
                cuenta = "20168294",
                imagen = "https://i.pinimg.com/236x/9d/ca/a2/9dcaa2df2182900462fee9a948671feb.jpg",
                correo = "lgonzalez@ucol.mx",
            ),
            Alumno(
                nombre = "Dario Hernández",
                cuenta = "20187649",
                imagen = "https://i.pinimg.com/236x/f8/be/58/f8be58a30e08ac7e7f0fce3c0a4cd6fc.jpg",
                correo = "dhernandez@ucol.mx"
            ),
            Alumno(
                nombre = "Yarely Sandoval",
                cuenta = "20197853",
                imagen = "https://i.pinimg.com/236x/6e/5a/7a/6e5a7a389ed115a02668ae9c1ec2e4d2.jpg",
                correo = "ysandoval3@ucol.mx"
            ),
            Alumno(
                nombre = "Rosa Isais",
                cuenta = "20120921",
                imagen = "https://i.pinimg.com/236x/13/ad/7a/13ad7adf6bce22972fc4645c328f7a93.jpg",
                correo = "risais@ucol.mx"
            ),
            Alumno(
                nombre = "Sebastian Quinteros",
                cuenta = "20148202",
                imagen = "https://i.pinimg.com/236x/b3/ca/89/b3ca8940699237be15ac311756858378.jpg",
                correo = "squinteros@ucol.mx"
            ),
            Alumno(
                nombre = "Sofía Amezcua",
                cuenta = "20187649",
                imagen = "https://i.pinimg.com/736x/71/26/eb/7126ebc5abf282c1cab3f50c1d796378.jpg",
                correo = "samezcua@ucol.mx"
            ),
            Alumno(
                nombre = "Luis Gónzalez",
                cuenta = "20168294",
                imagen = "https://i.pinimg.com/236x/9d/ca/a2/9dcaa2df2182900462fee9a948671feb.jpg",
                correo = "lgonzalez@ucol.mx",
            ),
            Alumno(
                nombre = "Dario Hernández",
                cuenta = "20187649",
                imagen = "https://i.pinimg.com/236x/f8/be/58/f8be58a30e08ac7e7f0fce3c0a4cd6fc.jpg",
                correo = "dhernandez@ucol.mx"
            ),
            Alumno(
                nombre = "Yarely Sandoval",
                cuenta = "20197853",
                imagen = "https://i.pinimg.com/236x/6e/5a/7a/6e5a7a389ed115a02668ae9c1ec2e4d2.jpg",
                correo = "ysandoval3@ucol.mx"
            ),
            Alumno(
                nombre = "Rosa Isais",
                cuenta = "20120921",
                imagen = "https://i.pinimg.com/236x/13/ad/7a/13ad7adf6bce22972fc4645c328f7a93.jpg",
                correo = "risais@ucol.mx"
            ),
            Alumno(
                nombre = "Sebastian Quinteros",
                cuenta = "20148202",
                imagen = "https://i.pinimg.com/236x/b3/ca/89/b3ca8940699237be15ac311756858378.jpg",
                correo = "squinteros@ucol.mx"
            )
        )

        val adapter = AlumnoAdapter(this,Alumnos_List)
        recyclerViewOk.adapter = adapter
        }
    }