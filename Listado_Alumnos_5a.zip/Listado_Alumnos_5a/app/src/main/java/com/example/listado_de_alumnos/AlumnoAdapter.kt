package com.example.listado_de_alumnos

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class AlumnoAdapter(private val context: Context, private val ListAlumnos:List<Alumno>):
    RecyclerView.Adapter<AlumnoAdapter.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlumnoAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_personas, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlumnoAdapter.ViewHolder, position: Int) {
        val ItemsViewModel = ListAlumnos[position]

        // sets the image to the imageview from our itemHolder class
        Glide.with(context).load(ItemsViewModel.imagen).into(holder.imgFoto)
        // sets the text to the textview from our itemHolder class
        holder.miNombre.text = ItemsViewModel.nombre
        holder.numCuenta.text = ItemsViewModel.cuenta
        holder.micorreo.text = ItemsViewModel.correo
    }

    override fun getItemCount(): Int {
        return ListAlumnos.size
    }
    inner class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val imgFoto: ImageView = itemView.findViewById(R.id.imgPersona)
        val miNombre: TextView = itemView.findViewById(R.id.tvNombre)
        val numCuenta: TextView = itemView.findViewById(R.id.tvCuenta)
        val micorreo: TextView = itemView.findViewById(R.id.tvCorreo)
    }

}